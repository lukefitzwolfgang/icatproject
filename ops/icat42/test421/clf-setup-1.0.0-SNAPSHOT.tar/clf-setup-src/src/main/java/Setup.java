import java.io.Console;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import javax.xml.namespace.QName;

import org.icatproject.DatafileFormat;
import org.icatproject.DatasetType;
import org.icatproject.Facility;
import org.icatproject.Group;
import org.icatproject.ICAT;
import org.icatproject.ICATService;
import org.icatproject.IcatExceptionType;
import org.icatproject.IcatException_Exception;
import org.icatproject.Investigation;
import org.icatproject.InvestigationType;
import org.icatproject.Rule;
import org.icatproject.User;
import org.icatproject.UserGroup;
import org.icatproject.Login.Credentials;
import org.icatproject.Login.Credentials.Entry;

public class Setup {

	private static enum Action {
		CREATE, DROP;
	}

	private static ICAT icatEP;
	private static String sessionId;

	private static void clear(String cicUserName, String guestUserName, String readerUsername)
			throws IcatException_Exception, ApplicationException {
		setAuthz(cicUserName, guestUserName, readerUsername);
		clearData();
		clearAuthz();
	}

	private static void clearData() throws IcatException_Exception {
		List<Object> lo = Setup.icatEP.search(Setup.sessionId, "Facility");
		for (Object o : lo) {
			System.out.println("Deleting " + o);
			Setup.icatEP.delete(Setup.sessionId, (Facility) o);
		}
	}

	private static void create(String cicUserName, String guestUserName, String readerUsername)
			throws IcatException_Exception, ApplicationException {
		setAuthz(cicUserName, guestUserName, readerUsername);
		Facility fac = Setup.createFacility("CLF", 90);

		InvestigationType invType = Setup.createInvestigationType(fac, "experiment");

		Setup.createInvestigation(fac, "None", "None", invType);
		Setup.createInvestigation(fac, "Temp", "Temp", invType);

		Setup.createDatafileFormat(fac, "png", "binary");
		Setup.createDatafileFormat(fac, "bmp", "binary");
		Setup.createDatafileFormat(fac, "pcx", "binary");
		Setup.createDatafileFormat(fac, "tiff", "binary");
		Setup.createDatafileFormat(fac, "jpg", "binary");
		Setup.createDatafileFormat(fac, "gif", "binary");
		Setup.createDatafileFormat(fac, "dat", "text");
		Setup.createDatafileFormat(fac, "xml", "text");

		Setup.createDatasetType(fac, "GD");
		Setup.createDatasetType(fac, "GQ");
		Setup.createDatasetType(fac, "GS");
		Setup.createDatasetType(fac, "PB");
		Setup.createDatasetType(fac, "HB");
	}

	private static void createDatafileFormat(Facility facility, String name, String formatType)
			throws IcatException_Exception {
		DatafileFormat dff = new DatafileFormat();
		dff.setFacility(facility);
		dff.setType(formatType);
		dff.setName(name);
		dff.setVersion("1");

		Setup.icatEP.create(Setup.sessionId, dff);

	}

	private static void createDatasetType(Facility facility, String name)
			throws IcatException_Exception {
		DatasetType dst = new DatasetType();
		dst.setFacility(facility);
		dst.setName(name);

		Setup.icatEP.create(Setup.sessionId, dst);

	}

	private static Facility createFacility(String shortName, int daysUntilRelease)
			throws IcatException_Exception {
		Facility f = new Facility();
		f.setName(shortName);
		f.setDaysUntilRelease(daysUntilRelease);
		f.setId(Setup.icatEP.create(Setup.sessionId, f));
		return f;
	}

	private static void createInvestigation(Facility facility, String name, String title,
			InvestigationType invType) throws IcatException_Exception {
		Investigation i = new Investigation();
		i.setFacility(facility);
		i.setName(name);
		i.setTitle(title);
		i.setType(invType);
		Setup.icatEP.create(Setup.sessionId, i);
	}

	private static InvestigationType createInvestigationType(Facility facility, String name)
			throws IcatException_Exception {
		InvestigationType type = new InvestigationType();
		type.setFacility(facility);
		type.setName(name);
		type.setId((Long) Setup.icatEP.create(Setup.sessionId, type));
		return type;
	}

	public static void main(String[] args) throws IcatException_Exception, MalformedURLException,
			ApplicationException {

		if (args.length == 0) {
			abort("You must specify create or drop");
		}

		Action action = null;
		if (args[0].equals("drop")) {
			action = Action.DROP;
		} else if (args[0].equals("create")) {
			action = Action.CREATE;
		} else {
			abort("You must specify create or drop");
		}

		Console console = System.console();
		if (console == null) {
			abort("Application has no console");
		}
		String rootpassword = new String(
				console.readPassword("Please enter the ICAT root password "));

		if (action == Action.DROP) {
			if (!(console.readLine("Please type 'DROP' to clear the database ")).equals("DROP")) {
				System.out.println("Exiting without action");
				System.exit(0);
			}
		}

		String cicUserName = "CIC";
		String guestUserName = "guest";
		String readerUserName = "reader";
		String urlString = ("http://localhost:8080");
		for (int i = 1; i < args.length; i++) {
			String name = args[i++];
			if (i < args.length) {
				if (name.equals("--CIC")) {
					cicUserName = args[i];
				} else if (name.equals("--guest")) {
					guestUserName = args[i];
				} else if (name.equals("--reader")) {
					readerUserName = args[i];
				} else if (name.equals("--url")) {
					urlString = args[i];
				} else {
					abort("Option " + name + " is not recognised.");
				}
			} else {
				abort("Option " + name + " has no value specified.");
			}
		}

		URL icatUrl = new URL(urlString + "/ICATService/ICAT?wsdl");

		ICATService icatService = new ICATService(icatUrl, new QName("http://icatproject.org",
				"ICATService"));
		Setup.icatEP = icatService.getICATPort();

		Setup.sessionId = login("root", rootpassword);

		if (action == Action.DROP) {
			clear(cicUserName, guestUserName, readerUserName);
		} else {
			create(cicUserName, guestUserName, readerUserName);
		}
	}

	private static void abort(String msg) {
		System.err.println(msg);
		System.exit(1);
	}

	private static String login(String username, String password) throws IcatException_Exception {
		Credentials credentials = new Credentials();
		List<Entry> entries = credentials.getEntry();
		Entry e;

		e = new Entry();
		e.setKey("username");
		e.setValue(username);
		entries.add(e);

		e = new Entry();
		e.setKey("password");
		e.setValue(password);
		entries.add(e);

		return icatEP.login("db", credentials);

	}

	private static void clearAuthz() throws IcatException_Exception {

		List<Object> lo = icatEP.search(Setup.sessionId, "Rule");
		for (final Object o : lo) {
			System.out.println("Deleting " + o);
			icatEP.delete(Setup.sessionId, (Rule) o);
		}

		lo = icatEP.search(Setup.sessionId, "UserGroup");
		for (final Object o : lo) {
			System.out.println("Deleting " + o);
			icatEP.delete(Setup.sessionId, (UserGroup) o);
		}

		lo = icatEP.search(Setup.sessionId, "User");
		for (final Object o : lo) {
			System.out.println("Deleting " + o);
			icatEP.delete(Setup.sessionId, (User) o);
		}

		lo = icatEP.search(Setup.sessionId, "Group");
		for (final Object o : lo) {
			System.out.println("Deleting " + o);
			icatEP.delete(Setup.sessionId, (Group) o);
		}
	}

	private static void setAuthz(String cicUsername, String guestUsername, String readerUsername)
			throws IcatException_Exception, ApplicationException {

		addUserGroupMember(cicUsername, cicUsername);
		addRule(cicUsername, "Investigation", "CRUD");
		addRule(cicUsername, "Dataset", "CRUD");
		addRule(cicUsername, "ParameterType", "CRUD");
		addRule(cicUsername, "DatasetParameter", "CRUD");
		addRule(cicUsername, "Datafile", "CRUD");
		addRule(cicUsername, "DatafileFormat", "CRUD");
		addRule(cicUsername, "DatasetType", "CRUD");
		addRule(cicUsername, "Facility", "R");
		addRule(cicUsername, "InvestigationType", "R");

		addUserGroupMember("root", "root");
		addRule("root", "DatafileFormat", "CRUD");
		addRule("root", "DatasetType", "CRUD");
		addRule("root", "Facility", "CRUD");
		addRule("root", "Investigation", "CRUD");
		addRule("root", "InvestigationType", "CRUD");
		addRule("root", "ParameterType", "CRUD");
		addRule("root", "User", "CRUD");
		addRule("root", "Group", "CRUD");
		addRule("root", "UserGroup", "CRUD");
		addRule("root", "Rule", "CRUD");

		addUserGroupMember(guestUsername, guestUsername);
		addRule(guestUsername, "DatasetType", "R");
		addRule(guestUsername, "ParameterType", "R");
		addRule(guestUsername, "DatafileFormat", "R");

		addUserGroupMember(readerUsername, readerUsername);
		addRule(readerUsername, "Investigation", "R");
		addRule(readerUsername, "Dataset", "R");
		addRule(readerUsername, "ParameterType", "R");
		addRule(readerUsername, "DatasetParameter", "R");
		addRule(readerUsername, "Datafile", "R");
		addRule(readerUsername, "DatafileFormat", "R");
		addRule(readerUsername, "DatasetType", "R");
		addRule(readerUsername, "Facility", "R");
		addRule(readerUsername, "InvestigationType", "R");
	}

	private static void addRule(String groupName, String what, String crudFlags)
			throws IcatException_Exception, ApplicationException {
		Rule rule = new Rule();
		if (groupName != null) {
			List<Object> os = icatEP.search(sessionId, "Group[name ='" + groupName + "']");
			if (os.size() != 1) {
				throw new ApplicationException("Group " + groupName + " does not exist");
			}
			Group g = (Group) os.get(0);
			rule.setGroup(g);
		}
		rule.setWhat(what);
		rule.setCrudFlags(crudFlags);
		icatEP.create(sessionId, rule);

	}

	private static void addUserGroupMember(String groupName, String userName)
			throws IcatException_Exception {
		Group group = null;

		List<Object> os = icatEP.search(sessionId, "Group[name ='" + groupName + "']");
		if (os.size() == 0) {
			group = new Group();
			group.setName(groupName);
			group.setId(icatEP.create(sessionId, group));
		} else if (os.size() == 1) {
			group = (Group) os.get(0);
		}

		User user = null;
		os = icatEP.search(sessionId, "User[name ='" + userName + "']");

		if (os.size() == 0) {
			user = new User();
			user.setName(userName);
			user.setId(icatEP.create(sessionId, user));
		} else if (os.size() == 1) {
			user = (User) os.get(0);
		}

		UserGroup userGroup = new UserGroup();
		userGroup.setUser(user);
		userGroup.setGroup(group);

		try {
			icatEP.create(sessionId, userGroup);
		} catch (IcatException_Exception e) {
			if (e.getFaultInfo().getType() == IcatExceptionType.OBJECT_ALREADY_EXISTS) {
				System.out.println("Ignore exception " + e.getMessage());
			} else {
				throw e;
			}
		}

	}

}
